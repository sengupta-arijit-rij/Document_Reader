import os

# AWS and Bedrock configuration
REGION = "us-east-1"
BUCKET = "bofa-poc"
MODEL_ID = "arn:aws:bedrock:us-east-1:970547359844:inference-profile/us.meta.llama4-scout-17b-instruct-v1:0"

OLLAMA_API_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "llama3.2-vision:11b"



target_folder="images"
output_folder="/tmp/Output_files/"
PDF_EXTENSION="pdf"

LOCAL_IMAGE_TMP_DIR = "./tmp_images"

# Supported file extensions
SUPPORTED_EXTENSION ={'.pdf','.png', '.jpg', '.jpeg'}
# Supported image extensions
IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg'}


MAX_RETRIES = 2
# Create local raw-data folder if it doesn't exist
LOCAL_RAW_DATA_DIR = "/tmp/raw-data"
os.makedirs(LOCAL_RAW_DATA_DIR, exist_ok=True)