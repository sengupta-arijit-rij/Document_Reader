from flask import Flask, request, jsonify, send_from_directory, render_template
import os
import json
import traceback
import fitz  # PyMuPDF
from werkzeug.utils import secure_filename
from model_util import prepare_message, prepare_message_trade, infer_with_retry
from utils import *
from config import MAX_RETRIES
from prompt import prompt_trade_register, prompt_passport, prompt_dl

# app = Flask(__name__)
app = Flask(__name__, static_folder='static', template_folder='template')
# Serve Angular index.html
@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_ui(path):
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        # Always return index.html for Angular routing
        return render_template("index.html")

# ---------------------------
# Config
# ---------------------------
VALID_DOCUMENT_TYPES_PROMPT = {
    "driving_licence": prompt_dl,
    "passport": prompt_passport,
    "trade_register": prompt_trade_register,
}

PDF_TYPE_DOCUMENTS = ["trade_register"]

BASE_DIR = os.getcwd()
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
GENERATED_IMAGES_FOLDER = os.path.join(BASE_DIR, "generated_images")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs")

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(GENERATED_IMAGES_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)


# ---------------------------
# Helpers
# ---------------------------
def generate_images_from_pdf(file_path):
    saved_image_paths = []
    doc = fitz.open(file_path)
    for page_num in range(len(doc)):
        pixmap = doc[page_num].get_pixmap(matrix=fitz.Matrix(4, 4))
        image_filename = os.path.join(
            GENERATED_IMAGES_FOLDER, f"page_{page_num + 1}.png"
        )
        pixmap.save(image_filename)
        saved_image_paths.append(image_filename)
    doc.close()
    return saved_image_paths


def process_document(file_path, doc_type):
    image_list = []
    ext = os.path.splitext(file_path)[1].lower().strip(".")

    try:
        if doc_type in PDF_TYPE_DOCUMENTS and ext == "pdf":
            image_list = generate_images_from_pdf(file_path)
            with open(file_path, "rb") as f:
                file_bytes = f.read()
            raw_text_data = raw_text_extraction(file_bytes, image_list)
            messages = prepare_message_trade(
                ext, raw_text_data, VALID_DOCUMENT_TYPES_PROMPT[doc_type]
            )
        else:
            with open(file_path, "rb") as f:
                file_bytes = f.read()
            if ext == "jpg":
                ext = "jpeg"
            raw_text_data = None
            messages = prepare_message(
                VALID_DOCUMENT_TYPES_PROMPT[doc_type], file_bytes, ext
            )

        result_json = infer_with_retry(messages, key=file_path, max_retries=MAX_RETRIES)
        print("result_json---->: ", result_json)

        if doc_type in ["driving_licence","passport"]:
            for field, value in result_json.items():
                value = result_json.get(field, "")
                cleaned_value = clean_text(value)

                if is_date(cleaned_value):
                    cleaned_value = normalize_date(cleaned_value)
                    result_json[field] = cleaned_value

        return result_json

    finally:
        # ✅ Cleanup generated images if any
        for img_path in image_list:
            if os.path.exists(img_path):
                try:
                    os.remove(img_path)
                except Exception as e:
                    print(f"Warning: could not remove {img_path} - {e}")



# ---------------------------
# Routes
# ---------------------------
@app.route("/ping", methods=["GET"])
def health_check():
    return jsonify({"status": "ok"}), 200


@app.route("/upload", methods=["POST"])
def upload_file():
    """
    Upload endpoint
    Form-data:
        - file: uploaded document
    Returns:
        - filename: filename stored in /uploads
    """
    try:
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400

        file = request.files["file"]
        filename = file.filename #secure_filename(file.filename)

        local_path = os.path.join(UPLOAD_FOLDER, filename)
        print(f"local_path---> {local_path}")
        file.save(local_path)

        return (
            jsonify(
                {
                    "message": "File uploaded successfully",
                    "file_name": filename,
                    "presigned_url": local_path,
                }
            ),
            200,
        )

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route("/process", methods=["POST"])
def process_file():
    """
    Process endpoint
    JSON body:
    {
      "filename": "doc1.pdf",
      "document_type": "trade_register"
    }
    """
    try:
        data = request.form
        filename = data.get("file_name")
        doc_type = data.get("document_type")

        if not filename or not doc_type:
            return jsonify({"error": "file_name and document_type are required"}), 400

        if doc_type not in VALID_DOCUMENT_TYPES_PROMPT:
            return jsonify(
                {
                    "error": f"Invalid document_type. Must be one of {list(VALID_DOCUMENT_TYPES_PROMPT.keys())}"
                }
            ), 400

        local_path = os.path.join(UPLOAD_FOLDER, filename)
        if not os.path.exists(local_path):
            return (
                jsonify({"error": f"File {filename} not found. Please upload first."}),
                404,
            )

        # Process
        print(f"processing the file-->{filename}")
        result = process_document(local_path, doc_type)

        # Save JSON result
        doc_output_folder = os.path.join(OUTPUT_FOLDER, doc_type)
        os.makedirs(doc_output_folder, exist_ok=True)

        json_filename = os.path.splitext(filename)[0] + ".json"
        json_path = os.path.join(doc_output_folder, json_filename)

        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        return (
            jsonify(
                {
                    "result_json": result
                }
            ),
            200,
        )

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500



@app.route('/compare', methods=['POST'])
def compare():
    try:
        # Ensure content type is JSON
        if not request.is_json:
            return jsonify({'error': 'Content-Type must be application/json'}), 415

        data = request.get_json(force=True)

        if 'actual' not in data or 'predicted' not in data:
            return jsonify({'error': 'Request JSON must contain "actual" and "predicted" fields'}), 400

        actual = data['actual']
        predicted = data['predicted']

        if not isinstance(actual, dict) or not isinstance(predicted, dict):
            return jsonify({'error': '"actual" and "predicted" must be JSON objects'}), 400

        accuracy = compare_json_accuracy(actual, predicted)
        return jsonify({'overall_accuracy': round(accuracy, 2)})

    except json.JSONDecodeError:
        return jsonify({'error': 'Invalid JSON format'}), 400
    except Exception as e:
        return jsonify({'error': 'Internal server error', 'details': str(e)}), 500
# ---------------------------
# Main
# ---------------------------
if __name__ == "__main__":
    # Run Flask on Windows VM
    app.run(host="0.0.0.0", port=8080, debug=True)
