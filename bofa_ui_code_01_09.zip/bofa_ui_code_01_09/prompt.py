trade_register_raw_data = """
You are an expert in extracting structured data from official trade register documents. These documents may contain details such as company registration information, directors, shareholders, capital structure, amendments, and various tables.

Your task is to extract **only** the visible and explicitly provided information from each page, preserving the **original wording, structure, and formatting**. Do **not** infer, summarize, interpret, or guess any content.

---

**Paragraphs**  
Extract all visible textual content in **natural reading order**, preserving the document’s structure.

- Retain all paragraph breaks, headings, and formatting as closely as possible.
- Do **not** paraphrase, reword, or omit any part of the text.
- If any section is illegible or blurred, mark it as: `"Unclear"`

---

**Tables**  
If one or more tables are present, extract each with the following format:

- Use keys like `"table_1"`, `"table_2"`, etc., based on the order of appearance.
- For each table, include:
  - **Description**: A short sentence describing the purpose of the table.
  - **Data**: A CSV-style string where:
    - Each row is comma-separated and enclosed in double quotes.
    - Each row appears on a new line.

**Example**:
"table_1": {
  "Description": "A table listing company representatives and their roles.",
  "Data": "\"\",\"Position\",\"Name\",\"Nationality\",\"Date of Appointment\",\"Authorized to Represent\"\n\"1\",\"Managing Director\",\"Anna Müller\",\"German\",\"2020-05-12\",\"Singly\"\n\"2\",\"Managing Director\",\"Max Schmidt\",\"German\",\"2019-11-01\",\"Jointly\""
}

If no tables are present, return:
"table_1": {
  "Description": "No tables found.",
  "Data": "N/A"
}

**Stamp Data**  
- Identify all visible stamps, seals, or signatures on the page.
- Use keys like "stamp_1", "stamp_2", etc., based on the order of appearance.
- Describe each element with as much detail as is legible (text, emblem, color, position, etc.).
- If any stamp or signature is unclear, write: "Unclear stamp" or "Unreadable signature".
- If none are found, return:
  "stamp_1": "No stamps or seals found."
---

**Output Format**:
- Your response must be only valid JSON.
- Do not include any commentary, markdown, or explanations outside the JSON.
- Output would be like this:
{
  "Paragraph_data": "Full extracted paragraph content here.",
  "table_1": {
    "Description": "...",
    "Data": "..."
  },
  "table_2": {
    "Description": "...",
    "Data": "..."
  },
  "stamp_1": "...",
  "stamp_2": "..."
}

**Guidelines:**  
- Do not hallucinate or assume missing data.  
- Return only what is **explicitly visible** in the document.  
- Clearly mark missing, unclear, or unreadable text as `"Unclear"`.

"""

prompt_trade_register = """
You are a highly skilled expert in extracting structured information from raw metadata found in Trade Register documents. Your task is to accurately analyze the provided metadata and extract the following key fields, returning them in strict JSON format with clear, concise, and reliable values:
- Legal Name
- Registered Address of Company
- Principal Place of Business
- Date of Birth (DOB)
- Address Details

Use the following output format:

{
  "legal_name": "<Full legal name of the company or individual>",
  "registered_address": "<Registered address of the company as per the document>",
  "principal_place_of_business": "<Main business address of the company as per the document>",
  "date_of_births": ["<DOB1>", "<DOB2>", ...],
  "address_details": ["<Address1>", "<Address2>", ...]
}

If any field is missing or not present in the text, strictly return its value as `null`. Do not add any extra commentary in JSON Response.

***Note***:
Strictly return the output in JSON format. Do not provide any extra commentary before or after the extracted JSON. ** Do not add triple backticks and do not add markdown formatting**
"""

prompt_passport = """
You are an OCR expert at extracting structured information from passport images of any country.

Read and analyze the image **line by line, from top-left to bottom-right**, exactly as text appears on the passport.  
Do not skip lines. Match each field only when the label or context is explicitly clear.  

Extract the following fields and return the output strictly in **valid JSON format**:

- ID Number
- ID Issuing Authority
- Country of Issuance
- Date of Issuance
- State of Issuance
- Validity Period

Expected JSON:
{
  "id_number": "<passport number>",
  "id_issuing_authority": "<official authority name>",
  "country_of_issuance": "<country that issued the passport>",
  "date_of_issuance": "<YYYY-MM-DD>",
  "state_of_issuance": "<state/region of issuance, or null if unavailable>",
  "validity_period": "<expiry date in YYYY-MM-DD format>"
}

Extraction Rules:

1. **ID Number**
- Must be strictly alphanumeric or numeric (usually an 8 to 9 digit number at the top right corner of the image).
- If blurred,return null. 
- If the extracted field is scratched, blurred, illegible, or OCR confidence is low, return null instead of guessing

2. **ID Issuing Authority**
- Look for official government body (e.g., “Government of India”, “U.S. Department of State”).
- Do not use country name alone.
- Do not infer from unrelated text.

3. **Country of Issuance**
- Must be explicitly mentioned as the issuing country or extracted from the authority line.
- Do not confuse with “Place of Birth” or “Nationality”.
- Never use “Place of Birth”, “Birthplace”, “POB”, “Address”, “Residence”, or “Nationality” as state_of_issuance.

4. **Dates (Issuance & Validity Period)**
- Always in ISO format: YYYY-MM-DD.
- Convert month names/abbreviations (e.g., “Oct”, “October”) into their numeric equivalent.
- Ensure distinction between issuance date and expiry/validity date.
- If unreadable return null.

5. **State of Issuance**
- Only extract if explicitly labeled as “State of Issuance”.
- Analyze, if the value is extracted from place of birth,if yes, then return null. 
- Do not take “Place of Birth” field for state of issuance.
- If not present return null.
- Do not hallucinate or guess.
- Do **NOT** use “Place of Issuance” values (e.g., Washington D.C.) or city names.
- Check if the state of issuance is taken from place of birth field, if so, then return null.

General Instructions:
- Parse the image sequentially: **top → down, left → right**.
- If multiple candidate values exist, choose the one closest to the field label.
- If any field is missing, blurred, or unreadable → return null.
- Do not hallucinate or guess values.
- Return **only the JSON object** (no explanations, commentary, or labels).
- Ensure JSON is valid and directly parseable.
- Do not add **JSON Output:** after extracting JSON data as it will be further dumped into a json file.
- Reason why you chose a value for that field

---

### Example 1 (U.S. Passport)

**Image text (simplified):**
- Passport No.: 100003106
- Issuing Authority: United States
- Country: United States of America
- ---

### Example 1 (U.S. Passport)

**Image text (simplified):**
- Passport No.: 100003106
- Issuing Authority: United States
- Country: United States of America
- Date of Birth: 01 Jan 1950
- Place of Birth: Washington D.C., U.S.A.
- Date of Issue: 02 Mar 2005
- Date of Expiry: 02 Mar 2015

**Correct JSON:**
{
  "id_number": "100003106",
  "id_issuing_authority": "United States",
  "country_of_issuance": "United States of America",
  "date_of_issuance": "2005-03-02",
  "state_of_issuance": null,
  "validity_period": "2015-03-02"
}

---Date of Birth: 01 Jan 1950
- Place of Birth: Washington D.C., U.S.A.
- Date of Issue: 02 Mar 2005
- Date of Expiry: 02 Mar 2015

**Correct JSON:**
{
  "id_number": "100003106",
  "id_issuing_authority": "United States",
  "country_of_issuance": "United States of America",
  "date_of_issuance": "2005-03-02",
  "state_of_issuance": null,
  "validity_period": "2015-03-02"
}

---
---

### Example 2 (U.S. Passport – California)
**Image text (simplified):**
- Passport No.: 910239248
- Issuing Authority: United States Department of State
- Country: United States of America
- Date of Birth: 07 Aug 1999
- Place of Birth: California, U.S.A.
- Date of Issue: 06 Feb 2008
- Date of Expiry: 05 Feb 2018

**Correct JSON:**
{
  "id_number": "910239248",
  "id_issuing_authority": "United States Department of State",
  "country_of_issuance": "United States of America",
  "date_of_issuance": "2008-02-06",
  "state_of_issuance": null,
  "validity_period": "2018-02-05"
}

---
"""


prompt_dl = """
You are an expert in extracting structured data from driving license images provided voluntarily by user.

Please extract the following fields from the provided image and return them in **strict JSON format**. 
When getting dates from the image, normalize them to YYYY-MM-DD format regardless of how they appear visually.:

- ID Number
- ID Issuing Authority
- Country of Issuance
- Date of Issuance
- State of Issuance
- Expiry Date (Validity Period)

---

**Critical Instructions:**

1. **State of Issuance**
   - Only extract the state/province if it is **explicitly mentioned** as part of the license issuance details.
   - **Do not** infer it from the **place of birth** or any unrelated field.

2. **Date of Issuance (ISS)**
   - This is the **date the license was issued** by the authority.
   - **Do not** confuse this with the **Date of Birth** DOB or any other date.
   - The format **must be**: `YYYY-MM-DD`  
   - If the date is not clearly labeled as the issuance date, return `null`.

3. **Expiry Date(EXP) (Expiration Date)**
   - The format **must be**: `YYYY-MM-DD`
   - **Do not** confuse this with the **date of birth** DOB or any other date.
   - If the expiry date is not clearly mentioned, return `null`.

---

**Output Format:**


{
  "id_number": "<license number>",
  "id_issuing_authority": "<authority that issued the license>",
  "country_of_issuance": "<country that issued the license>",
  "date_of_issuance": "<YYYY-MM-DD>",
  "state_of_issuance": "<state/province that issued the license, if applicable>",
  "expiry_date": "<YYYY-MM-DD>"
}

Only include the extracted JSON. If a field is not found, return its value as null.

Note:
Date difference between date_of_issuance and expiry_date should be close to 5 years, if not cross check the document for any other dates.
Strictly return the output in JSON format do not provide any extra commentary before or after the extraceted JSON
"""