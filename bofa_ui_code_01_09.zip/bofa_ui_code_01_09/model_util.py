import json
import re
import logging
import requests
import base64
from config import *



def extract_json(text):
    match = re.search(r'\{.*\}', text, re.DOTALL)
    if match:
        json_str = match.group()
        try:
            return json.loads(json_str)  # json_str is a string
        except json.JSONDecodeError as e:
            print(e)
            return text
    return None



# -------------------------
# Message Preparation
# -------------------------
def prepare_message(prompt, image_bytes, ext):
    """Prepare Ollama-style input from Bedrock-style message format."""
    if ext == "jpg":
        ext = "jpeg"
    return [
        {
            "role": "user",
            "content": [
                {"text": prompt},
                {"image": {"format": ext, "source": {"bytes": image_bytes}}}
            ]
        }
    ]


def prepare_message_trade(ext, raw_text_data, prompt):
    """Prepare Ollama-style input from Bedrock-style message format."""
    if ext.lower() == "jpg":
        ext = "jpeg"
    return [
        {
            "role": "user",
            "content": [
                {"text": prompt},
                {"text": json.dumps(raw_text_data)}
            ]
        }
    ]


# -------------------------
# Inference with Retry
# -------------------------
def infer_with_retry(messages, key=None, max_retries=MAX_RETRIES):
    """
    Run inference on Ollama with retry logic.

    Args:
        messages (list): Prepared messages (Bedrock-style).
        key (str): Identifier for logging.
        max_retries (int): Retry count.

    Returns:
        dict: Parsed JSON response.
    """
    for attempt in range(max_retries + 1):
        try:
            # Extract prompt and image (if any)
            prompt_text = ""
            image_b64 = None

            for m in messages[0]["content"]:
                if "text" in m:
                    prompt_text += m["text"] + "\n"
                elif "image" in m:
                    image_b64 = base64.b64encode(m["image"]["source"]["bytes"]).decode("utf-8")

            # Prepare payload for Ollama
            payload = {
                "model": OLLAMA_MODEL,
                "prompt": prompt_text,
                "stream": False,
                "options": {"temperature": 0.1, "top_p": 0.9}
            }
            if image_b64:
                payload["images"] = [image_b64]

            resp = requests.post(OLLAMA_API_URL, json=payload)
            if resp.status_code != 200:
                raise Exception(f"Ollama error: {resp.status_code} {resp.text}")

            result = resp.json()["response"]

            # Clean ```json wrappers
            # result = re.sub(r"^```[a-zA-Z]*\n?|```$", "", result.strip(), flags=re.MULTILINE)
            # return json.loads(result)
            # Post-Processing to get JSON ONLY
            result = extract_json(result)
            return result

            

        except json.JSONDecodeError as j:
            print("failed: ", result)
            print(f"JSON DECODE ERROR: {j}")
            if attempt == max_retries:
                raise Exception(f"Failed to parse JSON after {max_retries+1} attempts for {key}")

        except Exception as e:
            print(f"Error on attempt {attempt+1} for {key}: {e}")
            if attempt == max_retries:
                raise


# -------------------------
# Logging
# -------------------------
def setup_logging(log_file='application.log', level=logging.INFO):
    logger = logging.getLogger(__name__)
    logger.setLevel(level)
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(level)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger
