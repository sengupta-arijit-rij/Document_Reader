import fitz  # PyMuPDF
import os
import json
import time
import logging
import traceback
from jiwer import wer
from datetime import datetime
from model_util import *
from prompt import trade_register_raw_data  # still using your prompts


# -------------------------
# File Handling (Local)
# -------------------------
def save_pdf_pages_as_images(local_pdf_path, output_folder):
    """
    Convert PDF pages to images and save them locally.
    Returns list of saved image paths.
    """
    try:
        doc = fitz.open(local_pdf_path)
        image_paths = []

        for page_num in range(len(doc)):
            pixmap = doc[page_num].get_pixmap(matrix=fitz.Matrix(4, 4))  # 4x zoom
            image_path = os.path.join(output_folder, f"page_{page_num + 1}.png")
            pixmap.save(image_path)
            image_paths.append(image_path)

        doc.close()
        return image_paths

    except Exception as e:
        print(f"Error converting PDF to images: {e}")
        return []


def raw_text_extraction(pdf_bytes, images_list):
    """
    Extract raw text from PDF.
    If a page has no text, fallback to Ollama OCR using the page image.
    """
    document = fitz.open(stream=pdf_bytes)
    extracted_data = []

    for i, page in enumerate(document):
        page_dict = {}
        text = page.get_text()
        print(f"Processing Page {i+1}...")

        page_dict["Page Number"] = str(i + 1)

        if text.strip():
            # Normal PDF text
            page_dict["Paragraph_data"] = str(text)
        elif i < len(images_list):
            print("⚠️ No text from PDF page, using Ollama OCR fallback...")

            # Load page image
            image_path = images_list[i]
            ext = os.path.splitext(image_path)[1].lower().strip(".")
            if ext == "jpg":
                ext = "jpeg"

            with open(image_path, "rb") as f:
                image_bytes = f.read()


            # Prepare Ollama message
            messages = prepare_message(trade_register_raw_data, image_bytes, ext)

            # Run inference
            try:
                ocr_result = infer_with_retry(messages, key=f"page_{i+1}", max_retries=MAX_RETRIES)

                # If model returned JSON accidentally, stringify it
                if isinstance(ocr_result, dict):
                    page_dict["Paragraph_data"] = json.dumps(ocr_result, ensure_ascii=False)
                else:
                    page_dict["Paragraph_data"] = str(ocr_result)

            except Exception as e:
                print(f"OCR fallback failed for page {i+1}: {e}")
                page_dict["Paragraph_data"] = ""

        else:
            page_dict["Paragraph_data"] = ""

        extracted_data.append(page_dict)

    document.close()
    return extracted_data



# -------------------------
# Accuracy Comparison
# -------------------------
def clean_text(text):
    """Normalize spacing and lowercase text for comparison."""
    if text is None:
        return ""
    return " ".join(str(text).strip().split()).lower()


def compare_json_accuracy(actual_data: dict, predicted_data: dict) -> float:
    """
    Compare actual vs predicted JSON values using WER accuracy.
    """
    total_accuracy_sum = 0
    total_fields = 0

    for field, actual_value in actual_data.items():
        predicted_value = predicted_data.get(field, "")
        actual_clean = clean_text(actual_value)
        predicted_clean = clean_text(predicted_value)

        error_rate = wer(actual_clean, predicted_clean)
        accuracy = (1 - error_rate) * 100

        total_accuracy_sum += accuracy
        total_fields += 1

    return total_accuracy_sum / total_fields if total_fields else 0


def is_date(string):
    date_patterns = [
        r"\b\d{4}-\d{2}-\d{2}\b",          # YYYY-MM-DD
        r"\b\d{2}-\d{2}-\d{4}\b",          # DD-MM-YYYY
        r"\b\d{2}/\d{2}/\d{4}\b",          # MM/DD/YYYY or DD/MM/YYYY
        r"\b\d{1,2} \w+ \d{4}\b",          # D Month YYYY
        r"\b\w+ \d{1,2}, \d{4}\b"          # Month D, YYYY
    ]
    for pattern in date_patterns:
        if re.search(pattern, string):
            return True
    try:
        datetime.strptime(string, "%Y-%m-%d")
        return True
    except:
        return False

def normalize_date(date_str):
    date_formats = [
        "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y", "%d/%m/%Y",
        "%B %d, %Y", "%d %B %Y", "%b %d, %Y", "%d %b %Y"
    ]
    for fmt in date_formats:
        try:
            return datetime.strptime(date_str, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return date_str

def clean_text(text):
    """Normalize spacing and case."""
    if text is None:
        return ""
    return " ".join(str(text).strip().split()).lower()

